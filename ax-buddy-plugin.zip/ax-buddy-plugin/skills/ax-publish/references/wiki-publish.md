# wiki-publish 스킬

/ax-publish 커맨드에서 호출된다.
인터뷰 데이터를 Confluence Storage Format으로 변환하여 페이지를 생성한다.

---

## 페이지 기본 정보

- 페이지 이름: {업무명}_{작성자}
- 상위 페이지 ID: 1310721 (업무 프로세스 모음)
- 스페이스 키: ~712020e972b87f01b94a62935b2fcc758be805

---

## 페이지 구조

아래 순서로 구성한다: 요약 헤더 → 목차 → 섹션 1(업무 정의서) → 섹션 2(워크플로우) → 섹션 3(AI 활용 포인트)

---

### 요약 헤더

페이지 최상단에 한 줄 요약 표를 배치한다.

| 업무명 | 작성자 | 부서 | 작성일 |
|---|---|---|---|
| {업무명} | {작성자} | {부서명} | {YYYY-MM-DD} |

---

### 섹션 1. 업무 정의서

업무의 핵심 정보를 표로 구성한다. (AX 전환 요약 제외 — 3번으로 이동)

| 항목 | 내용 |
|---|---|
| 업무명 | 인터뷰에서 확정된 업무명 |
| 목적 | 인터뷰 Q1에서 수집 |
| 주기 | 인터뷰 Q2에서 수집 |
| Pain Point | 인터뷰 Q3에서 수집 (반복 작업, 휴먼 에러 포함) |

---

### 섹션 2. 업무 프로세스 워크플로우

**단계별 상세 표**

각 업무 단계를 표로 구성한다.

**도구 이모지 매핑**
| 도구 | 이모지 |
|---|---|
| 슬랙 | 💬 |
| 지라 | 📋 |
| Confluence (위키) | 📄 |
| 이메일 | 📧 |
| 엑셀 / 구글 스프레드시트 | 📊 |
| PDF | 📑 |
| 아지트 | 📢 |
| GWS (캘린더 / 구글 문서) | 📅 |
| 기타 / 없음 | 🔲 |

---

### 섹션 3. AI 활용 포인트

**AX 전환 요약** (상단에 1~2줄 텍스트로 배치)
인터뷰 전체 내용 기반으로 Claude가 핵심 자동화 가능 포인트를 1~2줄로 요약한다.

**MCP 연동형** — 슬랙, 지라, Confluence, 아지트, GWS 등 MCP로 연결 가능한 도구

| 도구 | Pain Point | 자동화 가능한 작업 | Claude Cowork에서 바로 써보기 | 기대 효과 |
|---|---|---|---|---|
| (도구) | (현재 불편한 점) | (자동화할 수 있는 구체적 작업) | "(Claude에게 바로 쓸 수 있는 구체적 프롬프트 예시)" | (절감되는 시간 또는 제거되는 문제) |

"Claude Cowork에서 바로 써보기" 작성 기준:
- 사용자가 Cowork 채팅창에 그대로 붙여넣을 수 있는 수준으로 작성
- 업무 인터뷰에서 나온 실제 내용을 반영
- 예시: "지라에 [과제명] 티켓 만들고 담당자를 [이름]으로 지정해줘"
- 예시: "슬랙 [채널명]에 요건 정의서 요청 메시지 보내줘. 내용은 [업무명] 자동화 과제야"

**파일 처리형** — 엑셀, CSV, PDF 등 파일 기반 작업

| 도구 | Pain Point | 자동화 가능한 작업 | Claude Cowork에서 바로 써보기 | 기대 효과 |
|---|---|---|---|---|
| (도구) | (현재 불편한 점) | (자동화할 수 있는 구체적 작업) | "(파일 첨부 후 Claude에게 바로 쓸 수 있는 프롬프트 예시)" | (절감되는 시간 또는 제거되는 문제) |

해당하는 도구가 없는 분류는 섹션을 생략한다.

---

## Confluence Storage Format 변환 규칙

페이지 전체를 아래 XML 구조로 변환하여 create_confluence_page 호출 시 content 값으로 사용한다.

```xml
<!-- 요약 헤더 -->
<table>
  <tbody>
    <tr><th>업무명</th><th>작성자</th><th>부서</th><th>작성일</th></tr>
    <tr><td>{업무명}</td><td>{작성자}</td><td>{부서명}</td><td>{YYYY-MM-DD}</td></tr>
  </tbody>
</table>

<!-- 목차 -->
<ac:structured-macro ac:name="toc">
  <ac:parameter ac:name="maxLevel">2</ac:parameter>
  <ac:parameter ac:name="minLevel">2</ac:parameter>
</ac:structured-macro>

<!-- 섹션 1 -->
<h2>1. 업무 정의서</h2>
<table>
  <tbody>
    <tr><th>업무명</th><td>{업무명}</td></tr>
    <tr><th>목적</th><td>{목적}</td></tr>
    <tr><th>주기</th><td>{주기}</td></tr>
    <tr><th>Pain Point</th><td>{Pain Point}</td></tr>
  </tbody>
</table>

<!-- 섹션 2 -->
<h2>2. 업무 프로세스 워크플로우</h2>

<!-- 단계별 상세 표 -->
<table>
  <tbody>
    <tr><th>단계</th><th>설명</th><th>도구</th></tr>
    <tr>
      <td><strong>{단계번호}. {단계명}</strong></td>
      <td>{단계 설명}</td>
      <td>{도구 이모지} {도구명} (Pain Point가 있으면) ⚠ {Pain Point 내용}</td>
    </tr>
  </tbody>
</table>

<!-- 섹션 3 -->
<h2>3. AI 활용 포인트</h2>
<p>{AX 전환 요약 — 1~2줄}</p>

<h3>MCP 연동형</h3>
<table>
  <tbody>
    <tr><th>도구</th><th>Pain Point</th><th>자동화 가능한 작업</th><th>Claude Cowork에서 바로 써보기</th><th>기대 효과</th></tr>
    <tr>
      <td>{도구 이모지} {도구명}</td>
      <td>{Pain Point}</td>
      <td>{자동화 포인트}</td>
      <td><em>"{Claude 프롬프트 예시}"</em><br/><a href="https://ax-kakaopay.atlassian.net/wiki/spaces/~712020e972b87f01b94a62935b2fcc758be805/pages/1015810/MCP">MCP 연동 가이드 →</a></td>
      <td>{기대 효과}</td>
    </tr>
  </tbody>
</table>

<h3>파일 처리형</h3>
<table>
  <tbody>
    <tr><th>도구</th><th>Pain Point</th><th>자동화 가능한 작업</th><th>Claude Cowork에서 바로 써보기</th><th>기대 효과</th></tr>
    <tr>
      <td>{도구 이모지} {도구명}</td>
      <td>{Pain Point}</td>
      <td>{자동화 포인트}</td>
      <td><em>"파일 첨부 후: {Claude 프롬프트 예시}"</em></td>
      <td>{기대 효과}</td>
    </tr>
  </tbody>
</table>
```

---

## 주의사항

- 특수문자(&, <, > 등)는 XML 이스케이프 처리한다. (&amp; &lt; &gt;)
- 도구가 MCP 연동형과 파일 처리형 모두 해당하면 각 섹션에 모두 포함한다.
- 해당 분류에 도구가 없으면 해당 섹션(h3 포함)을 생략한다.
- AX 전환 요약은 섹션 3 상단에 배치하며, 인터뷰 내용 기반으로 Claude가 직접 작성한다.
- "Claude Cowork에서 바로 써보기"는 사용자가 그대로 복붙할 수 있는 구체적인 프롬프트로 작성한다.
