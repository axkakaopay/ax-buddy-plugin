# /ax-publish

ax-buddy-plugin:ax-publish 스킬을 실행한다.
