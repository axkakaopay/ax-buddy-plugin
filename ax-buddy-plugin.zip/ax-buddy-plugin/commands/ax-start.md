# /ax-start

ax-buddy-plugin:ax-start 스킬을 실행한다.
